# Hello World in ThoughtScript
# Your first program in the natural thought-based language

think "Hello, World!" as greeting
express greeting

# Thinking about different greetings
think "Welcome to ThoughtScript!" as welcome
think "Programming with natural thoughts!" as tagline

express welcome
express tagline

# Let's think about the user
think "developer" as userType
express "Hello, " + userType + "!"